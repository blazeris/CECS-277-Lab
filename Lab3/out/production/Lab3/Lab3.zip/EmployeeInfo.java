/**
 * Team 16
 * Githel Lynn Suico
 * Nathan Lai
 * Interface to store constant values for employee parent
 */
public interface EmployeeInfo {
    double FACULTY_MONTHLY_SALARY = 5000.00;
    int STAFF_MONTHLY_HOURS_WORKED = 160;
}
